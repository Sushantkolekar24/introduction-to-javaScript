    //    body

    document.body.style.backgroundColor = "lightpink"

       
    // Heading


document.getElementById("heading").innerHTML = "ABOUT MYSELF"
document.getElementById('heading').style.color = 'red'
document.getElementById('heading').style.fontSize =  '50px'
document.getElementById('heading').style.fontWeight = 'bold'

      

            // p1

document.getElementById("p1").innerHTML = "Name- SUSHANT DATTATRAY KOLEKAR"
document.getElementById('p1').style.color = 'blue'
document.getElementById('p1').style.fontSize = '25px'
document.getElementById('p1').style.fontWeight = 'bold'

       


           //   p2



document.getElementById("p2").innerHTML = "Role - WEB DEVELOPER"
document.getElementById('p2').style.color = 'black'
document.getElementById('p2').style.fontSize= '25px'
document.getElementById('p2').style.fontWeight = 'bold'


            // p3

         document.getElementById("p3").innerHTML = "Location - MUMBAI"
         document.getElementById('p3').style.color = 'purple'
         document.getElementById('p3').style.fontSize = '25px'
         document.getElementById('p3').style.fontWeight = 'bold'









